# Orbit Island 0.4.3

Portable C#/.NET Dynamic Island for **Windows 11 or Windows 10 version 2004+**, x64. Screenshot reference: https://poni.web.id/en/. Orbit is independent of Poni.

[Download Orbit Island 0.4.3 Portable](https://github.com/vmrishi/Dynamic_Island_for_Windows/raw/refs/heads/download-v0.4.3/downloads/Orbit-Island-Portable-v0.4.3-win-x64.zip)

## Update / run

Quit the old Orbit process from the tray. Extract the entire new ZIP into a **new writable folder** and run `OrbitIsland.exe`. No installer or separate .NET runtime is needed. Copy your old **Data** folder beside the new EXE before launching to retain settings, tasks, notes, calendar and usage history. Keep all new runtime DLLs together; do not mix the old 0.3 runtime files with 0.4. This release adds Windows Runtime projection assemblies for direct media/radio control, so there is no small DLL-only patch.

Hover opens the clock notch; leaving collapses it. Esc closes an island overlay or collapses the notch; Alt+Shift+O toggles; Ctrl+, opens Orbit Settings. `portable.mode` keeps data beside the EXE. `--data-dir <path>` overrides storage.

## Changes in 0.4

- Dashboard quick toggles are rounded rectangles with **white ON backgrounds and dark icons**, rather than stretched circles. Control connectivity tiles retain the reference's blue highlight and have properly joined split-button corners.
- Progress tracks use a clipped rounded renderer. The day bar has a restrained gradient, rounded ends and subtle timeline divisions. Sliders have rounded tracks and inset thumbs.
- The island uses one fixed design surface inside a Viewbox. Overall width/display scaling resizes icons, text and sections together. Font and icon overrides are supported without independently stretching each widget. Compact/expanded, module and overlay transitions use eased bounds changes; routine media updates no longer rebuild the player every two seconds.
- A slim 7-DIP scrollbar replaces the default menu/content scrollbar. Empty/hover tooltips and mouse-click focus rectangles are removed. Keyboard-only focus outlines remain. Text fields have explicit inset padding so the caret stays away from the edge.
- All 73 interface symbols come from the standard **Lucide** set with consistent stroke weights. These are redistributable cross-platform icons, not Apple's restricted SF Symbols. Attribution is included in `Licenses`.
- Weather opens its full forecast view and refreshes on entry. It shows current conditions, humidity, wind, current-hour UV, pressure, sunrise/sunset and seven hourly/two-hourly and daily forecast columns, with distinct day/night/rain/snow/storm symbols. Location changes, refresh and error status are available inside the island. A new location is saved only after its forecast loads successfully.
- Screen Time attributes the preceding interval to the previous foreground app, splits at hour/midnight boundaries, ignores suspend/long polling gaps and uses the same date range for seven-day charts and totals. Friendly process names/icons are saved when available; short durations show seconds. Turning tracking off also stops collecting process metadata. Existing historical records are preserved rather than fabricated or rewritten.
- Tracking is opt-in. Idle periods over 60 seconds, secure/locked desktops and Orbit itself are excluded. An actively playing media session whose source matches the foreground process is kept active while watching/listening. Windows 10 ApplicationFrameHost child processes are resolved where available. The records are estimates from one-second foreground samples, not imported Windows history.
- Calendar month navigation no longer changes the selected event date. It has a Monday-first six-week grid, distinct selection/today states, in-island event creation/editing with date, time and duration, and duration-aware ICS export. Basic ICS import/export remains local; recurrence and TZID imports are not supported.
- Device, password, media-source, sound, event and screenshot dialogs are displayed as **island overlays**. The Settings app shortcut opens Orbit's settings rather than Windows Settings. The screenshot action captures the chosen monitor, saves under `Data/Screenshots` and offers an in-island preview/copy action.

## Music / browser media

Music metadata and transport now use **Windows Global System Media Transport Controls directly in-process**. The old global media-key control and PowerShell metadata polling are no longer used.

Start playback in a compatible browser or Windows app, open Home, then use **Choose source / the displayed source name** if needed. Play/pause, next, previous and seeking target the native session represented by the displayed track. Controls are enabled according to the player's advertised capabilities. Timeline position is refreshed/estimated from Windows timestamps, and artwork is cached/decoded at thumbnail size.

Chrome, Edge, Firefox, Spotify and Windows players work **when they expose a Windows media session**. Browser settings, DRM/private content and individual players can restrict metadata or actions. Orbit cannot control a player that supplies no media session. The source picker explains missing sessions or rejected commands instead of pretending to control an app or sending keys to a different player. These integrations still need live Windows/browser verification.

## Device controls inside the island

- **Wi-Fi:** native WLAN scans/status, saved-profile connection, personal WPA/WPA2/WPA3-SAE password entry, password changes and disconnect. Credentials are passed to Windows WLAN profiles and are not stored in Orbit's JSON. Enterprise/legacy authentication requires an already provisioned Windows profile. Windows location/privacy permissions can deny scanning; the error is displayed in the island. No automatic Windows Settings redirect is used.
- **Bluetooth:** native classic-device discovery and pairing/connection status. Connect/disconnect requests enable/disable supported audio/headset/HID profile services and wait for the reported state. BLE-only devices, unsupported profiles, driver restrictions and inaccessible radios are reported as unsupported/errors. Windows has no universal classic-device connect API. Secure pairing may require a native operating-system confirmation prompt; this is not a Settings redirect. Battery readings are not invented.
- **Sound:** active output/input device lists, default-device selection and mute controls are available in the island. Default selection uses Windows audio-policy COM and is subject to OS compatibility. Apps pinned to their own output can ignore system-default changes.
- **Brightness:** selected-monitor DDC/CI first, then matching WMI support where available. No unrelated monitor is selected as a fallback. Hardware without an exposed brightness API displays an explanation/retry action rather than opening Windows Settings.
- **Media/radio:** direct Windows Runtime APIs. The small PowerShell broker remains only for WMI brightness and optional system notification capture.

## Other limits

System CPU/RAM/network/disk readings are live. CPU temperature requires a compatible sensor provider and is shown as unavailable. AI Chat uses a separately running Ollama server. Calendar does not synchronize Google/Outlook accounts. Windows notification capture may need packaged app identity and OS permission; Orbit reminders work independently. Read/clear actions apply to Orbit's copy. A signed MSIX is not included.

## Build / validation

With the .NET 10 SDK on Windows, run `Build.ps1` for the runtime-dependent app or `Build-Portable.ps1` for the complete self-contained ZIP. `Theme.xaml` is compiled, and icon data is embedded in the assembly.

The release is cross-built on Linux. **Windows GUI, browser playback, Bluetooth pairing/connection, WLAN operations, audio switching and monitor hardware have not been executed here.** Build success and regression checks do not establish hardware compatibility.

`dotnet run --project tests/ModelTests.csproj` runs portable logic/native-layout checks. With `-- --assembly <OrbitIsland.dll>`, it also inspects the built PE's embedded icons/theme. There are 69 checks with the assembly inspection enabled.

`Capture-UI.ps1` beside the portable EXE (or in the repository after building) runs isolated Windows render checks, including the earlier frozen-geometry fix, white rectangular toggles, rounded progress clipping and compact/wide layout. It captures every module under `%TEMP%/OrbitVisualTest-*` for visual review. Those Windows-only checks are included but have not been run in this environment. `Test.ps1` retains the original Windows persistence/diagnostic entry points.

## 0.4.1 fixes

General settings now include **Dynamic Island adjustment**: overall size and collapsed width/height. Valid size, font and icon changes apply automatically after typing. Every module uses the same expanded island dimensions. Appearance changes grow width and height together, and a uniform scale keeps the island inside both display bounds. The default collapsed dimensions and top-attached outline retain the 0.3 shape; detached mode has rounded upper corners. Smooth transitions can be disabled in General and respect the Windows animation preference. Settings uses a matching native title bar (exact caption colors on Windows 11; dark/light caption support on Windows 10).

Weather, brightness, sunrise/sunset and other compound icons now keep their independent paths inside the icon canvas. A new Orbit app icon is embedded in the Windows executable and used by Settings and the tray. `tools/Generate-Icon.py` regenerates it with Pillow; Pillow is not required to build or run Orbit.

Wi-Fi lists saved profiles when Windows location privacy blocks network enumeration. **Join by name** connects to an exact SSID using an explicit adapter and security type, without requesting a nearby-network scan. Passwords go to Windows WLAN profiles, not Orbit JSON. Windows still requires location permission to enumerate nearby networks; Orbit cannot override that policy. When Windows hides the active profile, Orbit reports an unconfirmed connection request instead of claiming success. Saved profiles may be unavailable/offline; their signal is not fabricated.

Bluetooth enumeration now includes every accessible classic adapter, actions select a radio that knows the device, pairing receives the complete device information, and connection requests no longer disable profiles first or stop after the first enabled service. All supported installed classic audio/HID services are attempted and state is polled for up to 15 seconds. BLE-only and driver-specific devices remain subject to Windows API limitations.

Linux validation: build with `dotnet build source/OrbitIsland.csproj -c Release -p:EnableWindowsTargeting=true -o portable-output/cloud-build`, then `dotnet run --project tests/ModelTests.csproj -- --assembly portable-output/cloud-build/OrbitIsland.dll`. There are 42 portable checks with assembly inspection. `Capture-UI.ps1` additionally validates icon bounds and appearance extremes on Windows.

Windows acceptance checks still required: run `Capture-UI.ps1`; inspect every module at minimum/maximum text, icon and island scales and at 100%/150%/200% DPI; rapidly open/close and switch pages during transitions; verify the Settings caption in both themes; disable Location and exercise saved/manual Wi-Fi connections and disconnect; pair/connect/disconnect classic audio and HID devices, including multiple adapters, and confirm state in Windows. These live Windows checks cannot run in a Linux cloud environment.


## 0.4.2 notch and connection corrections

Quit every old Orbit process from the tray before launching this version. Normal launches now share one desktop mutex and check for older Orbit processes; separate portable folders can no longer silently start overlapping notches. Isolated visual tests remain exempt.

The native window no longer animates its Width/Height dependency properties. A centered WPF scene animates inside a temporary transparent host, and the current transition explicitly sets the final native bounds. Interrupted transitions cannot finalize an older size. Hover opening tracks actual pointer movement and the painted notch shape; rebuilding or shrinking the notch cannot rearm hover under a stationary pointer. In hover mode, a click/release on the clock does not open it; when hover is disabled, a fresh mouse press opens it.

General has a separate **Island theme** selector and **Reset appearance to defaults**. Reset restores original dimensions, colors, theme and hover behavior, preserving notes, tasks, usage data, modules and other feature settings. The Dashboard/Control **Windows theme** toggle changes Windows' app/system theme independently of Orbit.

Device connect/disconnect/switch actions stay inside Orbit. Existing Wi-Fi profiles use `netsh.exe wlan connect name=... interface=...` and `wlan disconnect interface=...`, with separate process arguments and no command-shell interpolation. New profile/password setup remains native WLAN. Connection commands are followed by state checks; an accepted command is not treated as proof of connection. Windows location restrictions still prevent nearby-network scanning and may hide which profile is active. The explicit **Windows Settings** fallback opens `ms-settings:network-wifi` or `ms-settings:bluetooth`; those URIs are navigation links, not connection APIs.

Before classic Bluetooth disconnect, Orbit saves the enabled profile GUIDs so they can be restored even when disabled services vanish from enumeration or Orbit restarts. Recognized audio/HID devices disconnected by older versions have driver-validated recovery candidates. Reconnecting restarts only the selected disconnected peer's supported profile drivers and requests uncached Windows Runtime service discovery. Disconnect retains the existing supported-profile action. Three consecutive state samples are required before reporting success. BLE-only, unsupported-profile, exclusive connections to other hosts, permissions and driver restrictions can still prevent a connection. Periodic refreshes no longer erase action errors.

Validation for this update: 60 portable checks with assembly inspection. `Capture-UI.ps1` adds native-window/scene size checks after normal and rapidly interrupted transitions, stray clock release/click checks, and independent island-theme checks. The WPF and device checks require Windows and were not run on the Linux build host. Run that script from the extracted new package and exercise real Wi-Fi/Bluetooth devices before considering their behavior verified.


## 0.4.3 Wi-Fi, flicker and height update

Wi-Fi defaults to **saved networks**. This path uses native profile enumeration and profile-based connection/disconnection with **ACM-only** notifications. It never calls nearby-network enumeration, scan, or the location-gated current-connection query. It keeps the native WLAN handle alive until Windows reports completion, checks the selected adapter/profile, and reports Windows' failure reason instead of treating command acceptance as success. Existing connectivity can appear as an unnamed connected adapter until a connection event identifies the profile. Saved profiles can be out of range; they are not a list of nearby networks. **Join by name** is available for adding a personal network without scanning.

The explicit **Nearby scan (location)** button switches to discovery, which remains subject to Windows' location policy. **Saved only** switches back. Orbit cannot enumerate nearby SSIDs without the permission Windows requires. No script, Settings URI or alternative UI removes that restriction. These native controls still require WLAN AutoConfig and permission to execute the selected profile.

Transition placement now computes its temporary host bounds before resizing the native window. Collapse no longer shrinks the host and immediately regrows it to start animation. Opening and closing keep shell opacity constant; module changes may fade only their content.

Settings is an activated owned window. While it is open, Orbit suspends its own always-on-top state and hover opening; live appearance previews preserve that relationship. Closing Settings restores the always-on-top preference.

**General → Expanded height** adjusts the common expanded content height (180–650; default 320). It applies automatically, persists across launches, and is restored by Reset appearance to defaults. Shorter islands scroll longer content rather than reducing the whole interface width or cutting off controls.

Validation: Windows x64 cross-build and 69 portable checks. The Windows-only visual suite includes transition host bounds, constant shell opacity, short/tall layouts and Settings ownership/topmost checks. Live Windows rendering and radio operations have not been run on this Linux host; run Capture-UI.ps1 on Windows and test the actual adapters.
