param([ValidateSet('brightness','setbrightness')][string]$Action='brightness',[int]$Value=50,[string]$DisplayId='')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
function BrightnessMonitor($Class) {
 $items=@(Get-CimInstance -Namespace root/WMI -ClassName $Class)
 if($DisplayId){$items=@($items|Where-Object {$_.InstanceName.StartsWith($DisplayId,[StringComparison]::OrdinalIgnoreCase)})}
 if($items.Count -ne 1){throw 'No unambiguous WMI brightness control for the selected display.'}
 return $items[0]
}
try {switch($Action) {
 'brightness' {$b=BrightnessMonitor 'WmiMonitorBrightness';@{value=$b.CurrentBrightness}|ConvertTo-Json -Compress}
 'setbrightness' {if($Value -lt 0 -or $Value -gt 100){throw 'Brightness must be 0–100.'};$b=BrightnessMonitor 'WmiMonitorBrightnessMethods';$b|Invoke-CimMethod -MethodName WmiSetBrightness -Arguments @{Timeout=[uint32]1;Brightness=[byte]$Value}|Out-Null;'{"ok":true}'}

}}catch{@{error=$_.Exception.Message}|ConvertTo-Json -Compress;exit 1}
