param([switch]$Launch)
$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
if (-not (Test-Path (Join-Path $taskRoot 'OrbitIsland.exe'))) { throw 'Run this script from the extracted Orbit Island folder, beside OrbitIsland.exe.' }
if (Get-Process OrbitIsland -ErrorAction SilentlyContinue | Where-Object { $_.SessionId -eq (Get-Process -Id $PID).SessionId }) { throw 'Quit the old Orbit copy from its tray icon, then run this script again.' }
$dev = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModelUnlock' -ErrorAction SilentlyContinue
if ($dev.AllowDevelopmentWithoutDevLicense -ne 1) { throw 'Development registration requires Windows Developer Mode. Enable it yourself in Windows Settings > For developers if you want this development build registered. This script did not change that setting.' }
Add-AppxPackage -Register (Join-Path $taskRoot 'AppxManifest.xml')
$package = Get-AppxPackage -Name 'OrbitIsland.Notifications'
if (-not $package) { throw 'Windows did not register the app.' }
Write-Host 'Registered Orbit Island Notifications. Launch this Start-menu entry, then enable Capture Windows system notifications in Orbit Settings > Notifications and allow the Windows permission prompt.'
if ($Launch) { Start-Process explorer.exe -ArgumentList @("shell:AppsFolder\$($package.PackageFamilyName)!Orbit") }
