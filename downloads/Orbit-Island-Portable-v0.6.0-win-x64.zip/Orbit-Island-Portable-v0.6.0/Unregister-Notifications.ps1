$ErrorActionPreference = 'Stop'
if (Get-Process OrbitIsland -ErrorAction SilentlyContinue | Where-Object { $_.SessionId -eq (Get-Process -Id $PID).SessionId }) { throw 'Quit Orbit from its tray icon before removing registration so its latest data can be backed up.' }
$package = Get-AppxPackage -Name 'OrbitIsland.Notifications'
if (-not $package) { Write-Host 'No Orbit notification registration was found.'; return }
$state = Join-Path $env:LOCALAPPDATA "Packages\$($package.PackageFamilyName)\LocalState"
if (Test-Path $state) {
    $backup = Join-Path $PSScriptRoot ('NotificationDataBackup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    Copy-Item -Path $state -Destination $backup -Recurse
    if ((Test-Path (Join-Path $state 'island.json')) -and -not (Test-Path (Join-Path $backup 'island.json'))) { throw 'Data backup failed. Registration was not removed.' }
    Write-Host "Registered-app data backed up to $backup"
}
$package | Remove-AppxPackage
Write-Host 'Notification-enabled registration removed. Portable files and the data backup were kept.'
