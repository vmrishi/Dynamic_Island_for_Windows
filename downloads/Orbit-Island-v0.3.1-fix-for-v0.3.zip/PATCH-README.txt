Orbit Island 0.3 -> 0.3.1 startup fix

Quit Orbit from its tray icon first. Extract the files from this ZIP directly
into the folder containing your existing portable OrbitIsland.exe, replacing
the five matching files. Keep all existing runtime DLLs and your Data folder.
Run OrbitIsland.exe again. This patch requires the v0.3 portable package.
For a fresh installation, download the full v0.3.1 portable ZIP instead.
