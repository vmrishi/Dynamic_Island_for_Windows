# Orbit Island 0.5.0

Dynamic Island for Windows 11 / Windows 10 version 2004 or newer, x64. Self-contained .NET 10 WPF application. Orbit is independent of Poni; the original screenshot reference is https://poni.web.id/en/.

[Download Orbit Island 0.5.0 Portable](https://github.com/vmrishi/Dynamic_Island_for_Windows/raw/refs/heads/download-v0.5.0/downloads/Orbit-Island-Portable-v0.5.0-win-x64.zip)

## Update and run

Quit the old copy from its tray icon. Extract the entire ZIP into a new writable folder. Copy your old `Data` folder beside the new EXE before launching to preserve settings, tasks, notes and history. Run `OrbitIsland.exe`; no separate .NET installation is needed. Keep the new runtime DLLs together. Orbit prevents overlapping copies on the same desktop.

Hover opens the notch and leaving collapses it. Escape closes overlays or collapses; Alt+Shift+O toggles; Ctrl+, opens Orbit Settings. Disable hover opening in General if you prefer clicking. `portable.mode` stores data beside the executable; `--data-dir <path>` overrides storage.

## Changes in 0.5.0

- Collapse and expansion animate the painted notch inside one fixed transparent native window. Normal transitions never resize or reposition the HWND. The outline remains opaque, content crossfades, and interrupted animations continue from their current size. Unused transparent space leaves the desktop clickable. Smooth animations respect both General settings and the Windows animation preference.
- Smaller icons, text and padding fit the island without page scrollbars. Weather uses a compact forecast layout. Long lists use previous/next page buttons. The header fits all enabled modules, and content scales down when the available height is smaller. General's Expanded height still controls the common island height. The separate Settings window can scroll.
- The eye-off button switches to a notch with half the normal painted width and height, without the clock. Open the island and press the eye button to restore the clock.
- Reminders, health notices and tips appear as queued 2.5-second banners in the normal notch, replacing the time. New system notifications can use the same queue after permission is enabled. Banners wait while the island is expanded, then restore the prior clock or half-size mode. Notifications remain in Orbit's Notifications history (latest 500). Click a banner to open that history. Notification settings include a test button.
- The location input uses an inset native text host and an adorner layer within the scaled layout to keep its caret aligned inside the box.
- Dashboard Apps has a Customize button and a Dashboard page in Settings. Add files, shortcuts or installed apps; remove entries; drag rows or tiles to reorder. Arrow buttons are available in Settings, and dropped files can be added directly. The default Dashboard Settings app opens Windows system settings (`ms-settings:`).

## Windows system notification capture

Orbit's own reminders work immediately. Reading other Windows apps' notifications requires package identity, the `userNotificationListener` capability and explicit Windows permission. Running the standalone portable EXE does not provide identity.

This development build includes `AppxManifest.xml`, assets, and `Register-Notifications.ps1`. Follow `NOTIFICATIONS-SETUP.txt`: quit Orbit, keep its folder in a permanent location, enable Windows Developer Mode yourself if desired, register, and launch **Orbit Island Notifications** from Start. In Orbit Settings > Notifications, enable capture and accept Windows' prompt. The helper does not change Developer Mode or execution policy. A signed MSIX is not included.

Existing Windows notifications are imported without replaying old banners. Read/clear applies to Orbit's copy. The registered app uses its Windows application-data folder and imports portable `Data/island.json` on first launch if no registered data exists. Back up your Data folder before changing versions. `Unregister-Notifications.ps1` backs up registered data before removing registration.

**Development registration and the live permission flow have not been executed on this Linux build host.** Windows policy can restrict registration or notification access.

## Appearance and connections

General provides overall scale, compact dimensions, expanded height, font/icon sizes, monitor, colors, opacity, a separate Island light/dark selector and Reset appearance. Reset preserves other feature settings and saved content. Dashboard/Control's Windows theme toggle changes Windows independently. Settings uses a matching native title bar and stays in front of the island.

Wi-Fi defaults to saved profiles using native profile enumeration, connection/disconnection and ACM-only completion notifications. This path does not scan nearby networks or query the location-gated current connection. Windows can hide the current SSID; the adapter then appears unnamed. Saved profiles can be out of range. Join by name supports personal networks without scanning; passwords go to Windows WLAN profiles. The optional Nearby scan remains subject to Windows Location permission. Orbit cannot override that requirement. The working 0.4.3 Wi-Fi controls are retained.

Bluetooth controls retain supported classic audio/headset/HID profile restoration, pairing and state checks. BLE-only devices, unsupported profiles, device connections to other hosts and driver restrictions can prevent actions. Windows has no universal device-connect API. Audio output/input selection uses Windows audio-policy APIs; brightness uses monitor DDC/CI or matching WMI where available. Unsupported hardware displays an explanation. The PowerShell broker is used only for WMI brightness.

Media uses Windows Global System Media Transport Controls for session selection, metadata and transport. Browsers/players must expose a Windows media session; DRM/private content and player settings can restrict control. No global media keys are sent to unrelated apps.

Screen Time is opt-in and estimates active foreground usage from one-second samples, excluding idle/locked time and suspend gaps. It is not imported Windows history. Calendar is local, with basic ICS import/export; recurrence/TZID imports and online account synchronization are unsupported. AI Chat requires a running Ollama endpoint. Sensor-dependent CPU temperature may be unavailable.

## Build and validation

Use .NET 10 SDK on Windows: `Build.ps1` for the runtime-dependent app or `Build-Portable.ps1` for a self-contained ZIP. Theme resources and icons are embedded. Icons use the Lucide set; attribution is in `Licenses`. The Orbit app icon can be regenerated with `tools/Generate-Icon.py` and Pillow.

The Windows x64 build was cross-compiled on Linux. 77 portable regression checks passed with built-assembly inspection. They cover persistence, geometry, the notification queue, Dashboard ordering, usage/calendar logic, radio structures and embedded resources. Run:

```
dotnet run --project tests/ModelTests.csproj -- --assembly <path-to-OrbitIsland.dll>
```

`Capture-UI.ps1` runs isolated Windows checks and captures modules under `%TEMP%/OrbitVisualTest-*`. It includes fixed native-window bounds during normal/interrupted transitions, theme independence, half-size mode, banners, fitted pages, caret bounds and Settings ownership. These Windows-only checks are included but have not been executed here.

Actual Windows rendering/flicker, DPI, notification registration/permission, media, Wi-Fi/Bluetooth, sound and monitor hardware still require Windows verification. Build and portable test success do not establish their live behavior.
